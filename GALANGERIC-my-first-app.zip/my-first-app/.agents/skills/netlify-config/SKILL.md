---
name: netlify-config
description: Configure Netlify builds and routing via netlify.toml, _redirects, and _headers. Use when setting a build command or publish directory, validating netlify.toml against its JSON schema, adding redirects/rewrites/proxies or an SPA fallback rewrite, or setting custom response headers or basic auth. Also use when managing environment variables and secrets, scoping vars per deploy context, marking a var as secret or disabling secret scanning, handling sensitive vars in fork Deploy Previews, configuring functions bundling or the Netlify Server region/size, ignoring builds, or wiring up a monorepo or JavaScript SPA on Netlify.
---

# Netlify configuration

Config lives in three files at the repo **root** (or the base/package directory for monorepos):
- `netlify.toml`: build, contexts, plugins, functions, server, redirects, headers, dev.
- `_redirects`: plain-text redirect/rewrite rules, saved to the **publish directory**, no extension.
- `_headers`: plain-text response headers, saved to the **publish directory**.

`netlify.toml` values **take precedence over the Netlify UI** when they conflict. Paths in `netlify.toml` are absolute relative to the **base directory** (root `/` by default).

## Modern vs legacy syntax to reach for
- Schema: start `netlify.toml` with `"$schema" = "https://open-api.netlify.com/netlify.schema.json"` (key is quoted). Editors and agents with TOML JSON-schema support suggest and validate properties. In VS Code, use the Even Better TOML extension. Netlify ignores the key at build/deploy. **A schema-valid file can still fail to build**, because checks like whether a directory exists happen only during the build.
- Functions bundler: use `node_bundler = "esbuild"`. `zisi` is the legacy JS default. TypeScript always uses `esbuild`.
- Temporary redirect: use `status = 302`. `307` is **unsupported**.
- Gatsby Image CDN: use `NETLIFY_IMAGE_CDN`, not the deprecated `GATSBY_CLOUD_IMAGE_CDN`.
- Injecting env values into TOML: `key = "$VAR"` is **NOT supported** (except `signed` in proxy redirects). Use a build-command `sed` substitution or a build plugin (see below).

## `netlify.toml` build + contexts

```toml
"$schema" = "https://open-api.netlify.com/netlify.schema.json"

[build]
  base = "frontend"
  publish = "dist"
  command = "npm run build"
  environment = { NODE_VERSION = "18" }

[context.production]
  publish = "output/"
  command = "make publish"

[context.deploy-preview]
  publish = "dist/"

[context."feat/branch"]        # quote names with special characters
  command = "npm run preview"
```

`[build]` runs in **Bash**. Context-aware keys include `[build]` and `[[plugins]]`. They do **NOT** include `[[redirects]]` or `[[headers]]`, which are always global. Precedence, least→most specific: UI < toml < any-context property < `[context.<name>]` < `[context.branchname]`.

## Redirects and rewrites

`_redirects` rules are processed **first**, then `netlify.toml`. Within each, the **first matching rule top-to-bottom wins**, so list specific rules before general ones. Edge functions run before redirects.

SPA history-`pushState` fallback (required for clean URLs):
```
/*  /index.html  200
```
```toml
[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

`_redirects` syntax is `from to [status] [conditions]`. Lines starting with `#` are comments, paths are case-sensitive, and special chars must be URL-encoded:
```
/home         /              301
/my-redirect  /              302
/ecommerce    /store-closed  404          # custom 404 for a path
/pass-through /index.html    200          # rewrite
/best-pets/dogs /best-pets/cats.html 200! # force/shadow (! or force=true)
/news/*  /blog/:splat                     # splat
/news/:month/:date/:year/:slug  /blog/:year/:month/:date/:slug   # placeholders
/store id=:id  /blog/:id  301             # query params
/  /anz  302  Country=au,nz               # no spaces in value list
/israel/*  /israel/he/:splat  302  Language=he
/* /legacy/:splat 200 Cookie=is_legacy,my_other_cookie
```

`[[redirects]]` keywords:
- `from`, `to`
- `status` (default `301`)
- `force` (default `false`; same as `!`/shadow)
- `query` (`query = {path = ":path"}`)
- `conditions` (`{Language, Country, Role, Cookie}`)
- `headers` (proxy request headers)
- `signed` (env var name for signed proxies)

**Gotchas:**
- You **cannot** add or remove a trailing slash with a redirect. The CDN normalizes URLs first, so a `/x/ → /x 301!` rule loops infinitely. Rely on Pretty URLs (default on).
- Splat asterisks work only at the **end** of a segment (`/jobs/*`), not mid-path (`/jobs/*.html` is invalid). Placeholders (`:x`) work only at the start of a segment. You can't mix a wildcard and a placeholder in one segment.
- You can't exclude a path from a splat. Put a more specific rule first instead.
- `Country` takes ISO 3166-1 alpha-2 codes. Language redirects match only the **first** `Accept-Language` entry.
- Role-based redirects with external auth providers are **Enterprise-only**.
- For 10,000+ redirects, use wildcards/placeholders or Edge Functions. Oversized serialized output fails the deploy.

## Proxies

```
/api/*           https://api.example.com/:splat        200
/netlify-site/*  https://my-other-site.netlify.app/:splat  200   # use .netlify.app, not custom domain
```
```toml
[[redirects]]                     # custom request headers + force
  from = "/search"
  to = "https://api.mysearch.com"
  status = 200
  force = true
  headers = {X-From = "Netlify"}
```
Signed proxy rules:
- `signed` names an env var scoped to **Runtime**.
- The rule must live in `netlify.toml`.
- JWS signing works for external targets only, not Netlify→Netlify.

```toml
[[redirects]]
  from = "/search"
  to = "https://api.mysearch.com"
  status = 200
  force = true
  signed = "API_SIGNATURE_TOKEN_PLACEHOLDER"
```

**Gotchas:**
- Cross-team rewrites are disallowed.
- Rewrites within the same password-protected site are OK, but not across separate protected sites.
- Proxy timeout is **26 s**.
- Only one hop by default.
- Assets with relative paths break; use absolute paths or `<base>`.
- Looping rules are silently ignored.

## Custom headers

```
/*
  X-Frame-Options: DENY
/templates/index2.html
  X-Frame-Options: SAMEORIGIN
```
For multi-value headers, repeat the key (`_headers`) or use a multiline TOML string:
```toml
[[headers]]
  for = "/*"
  [headers.values]
  cache-control = '''
  max-age=0,
  no-cache,
  no-store,
  must-revalidate'''
```

**Gotchas:**
- Headers in `_headers`/`netlify.toml` are **global**, NOT scoped to branch/context. Workaround: remove global headers, keep header files in a custom dir, and `cp` them into the publish dir from a per-context build command:
  ```toml
  [context.staging]
    command = "npm run build && cp ./custom-headers/_stagingHeaders ./dist/_headers"
  ```
- Headers apply only to files from Netlify's store. They do **NOT** apply to proxied content or function/edge (SSR) responses, which must set their own headers.
- Server-set names are ignored, including `Content-Length`, `Content-Encoding`, `Location` (use redirects), `Set-Cookie`, and `Server`.
- Basic auth headers are **Pro/Enterprise only**.
- Cross-subdomain cookies need a custom domain, because `netlify.app` is on the Public Suffix List.

## Functions

```toml
[functions]
  directory = "myfunctions/"          # default: <base>/netlify/functions
  node_bundler = "esbuild"
  external_node_modules = ["package-1"]  # esbuild only; native add-ons etc.
  included_files = ["files/*.md"]        # ! prefix excludes

[functions."api_*"]                    # glob/named blocks concatenate with top-level
  external_node_modules = ["package-2"]
  included_files = ["!files/post-1.md"]
```

## Netlify Server `[server]`

```toml
[server]
  region = "fra"     # Frankfurt
  size = "medium"    # medium instances, 2 GB memory
```
- Accepts the same settings as the server's configuration: https://docs.netlify.com/build/server/configuration/
- **If the server entry file also sets a property, the entry file wins** over `[server]`.
- Runtime env vars for Netlify Server must be set in UI/CLI/API with a scope that includes **Functions**.

## Environment variables

Two storage methods:
- **UI / CLI / API**: stored on Netlify, not in the repo.
  - Supports site + shared vars, per-context values, and scopes.
  - Reaches builds, functions/edge/Netlify Server/ODB, snippet injection, forms, and signed proxies.
  - **Recommended for anything sensitive.**
- **`netlify.toml`**: stored in the repo.
  - Site vars only, with per-context values.
  - **No scope selection**: everything gets **Builds** + **Post processing**.
  - Reaches builds and snippet injection only.

`netlify.toml` env vars **override** same-key UI/CLI/API vars.

Per-context values in TOML:
```toml
[context.production]
  environment = { NODE_VERSION = "14.15.3" }
[context.deploy-preview.environment]
  NOT_PRIVATE_ITEM = "not so secret"
[context.branch-deploy.environment]
  NODE_ENV = "development"
```

CLI:
```bash
netlify env:set KEY value          # --secret marks it a secret
netlify env:import .env             # site vars; --replace-existing wipes others first
netlify env:unset KEY
netlify env:list --plain --context production > .env
netlify build                       # local build with Netlify's env vars
```
API: `createEnvVars` / `updateEnvVar` (`is_secret: true`) / `setEnvVarValue` / `deleteEnvVar` / `deleteEnvVarValue`.

**Access syntax:** Bash `$VAR` in `build.command`/`ignore.command`; `process.env.VAR` in Node scripts and plugins.

**Scopes** (Pro/Enterprise; default is all scopes):
- Builds: site builds.
- Functions: Functions, Edge Functions, Netlify Server, ODB.
- Runtime: forms, signed proxies.
- Post processing: snippet injection.

Shared vars are Pro/Enterprise and **Team-Owner-only** to read/edit. When a site var and a shared var use the same key, precedence resolves **per scope**: the site var only wins within the scopes it actually carries.

**Naming/limits:**
- Keys use only alphanumerics and underscores, and must start with a letter (`1KEY` and `_KEY1` are invalid).
- Keys ≤255 chars, values ≤5,000 chars.
- Read-only variable names are reserved.
- Changes need a build + deploy.

**Set the build language via reserved config vars**: `NODE_VERSION`, `NPM_FLAGS`, `YARN_VERSION`, `BUN_VERSION`, `RUBY_VERSION`, `PHP_VERSION`, `PYTHON_VERSION`, `GO_VERSION`, `HUGO_VERSION`, `PNPM_FLAGS`, `NPM_TOKEN` (Yarn: `YARN_NPM_AUTH_TOKEN`), etc.

**Must be set in UI/CLI/API, NOT `netlify.toml`**, because they are read before `netlify.toml` (after the repo is cloned) or are runtime-only: `AWS_LAMBDA_JS_RUNTIME`, `GIT_LFS_ENABLED`, `GIT_LFS_FETCH_INCLUDE`, `NETLIFY_BUILD_DEBUG`.

**`CI` gotcha:** `CI` defaults to `true`. If it breaks a build, prepend `CI='' ` to the build command.

### Injecting env values into headers/redirects
`key = "$VAR"` is unsupported. For headers and redirects, substitute values from the build command (the var's scope must include **Builds**):
```toml
[build]
  command = "sed -i \"s|HEADER_PLACEHOLDER|${PROD_API_LOCATION}|g\" netlify.toml && yarn build"
```
`sed` substitution works **only** for `[[headers]]`/`[[redirects]]`, which are read after the build. It is **not** visible to build plugins, which run before the build command. For changes plugins must see, use a local build plugin that edits `netlifyConfig`.

### Useful read-only build vars
`CONTEXT` (`production`/`deploy-preview`/`branch-deploy`/`dev`), `BRANCH`, `COMMIT_REF`, `CACHED_COMMIT_REF`, `PULL_REQUEST`, `REVIEW_ID`, `URL`, `DEPLOY_URL`, `DEPLOY_PRIME_URL`, `SITE_ID`, `SITE_NAME`.

## Secrets Controller

Flag a var as secret with `Contains secret values` (UI), `--secret` (CLI), or `is_secret: true` (API). The policy is enforced and can't be customized:
- Secret values are **write-only**: there is no readable version after setting, and the flag can't be removed to reveal the value.
- Secrets need explicit contexts + scopes and **cannot** carry the `post processing` scope.
- Only code on Netlify (edge/serverless/build) reads unmasked values. Code off Netlify sees masked values.
- The `dev`-context value is exempt and stays unmasked from UI/CLI/API. `netlify build` never emits raw values.

**Secret scanning** runs automatically once any var is secret, and also through smart detection. It fails the build on detection and logs the location. Configure it with env vars set per context:
- `SECRETS_SCAN_ENABLED=false` disables **all** scanning, which removes all secret protection.
- `SECRETS_SCAN_SMART_DETECTION_ENABLED=false` disables smart detection only.
- `SECRETS_SCAN_OMIT_KEYS` and `SECRETS_SCAN_OMIT_PATHS` take comma lists. Paths are relative to the repo root; globs are OK.
- `SECRETS_SCAN_SMART_DETECTION_OMIT_VALUES` safelists false positives. **Prefer** this over disabling.
- Smart detection is available on Personal/Pro/Enterprise.

Scanning covers all build files. It checks secret values longer than 4 chars that aren't booleans, searching plaintext, base64, and URI-encoded permutations.

### Untrusted deploys and sensitive variables (public repos only)
Deploy Previews from forks of a **public** repo are governed by the project's untrusted deploys policy: https://docs.netlify.com/deploy/deploy-overview#untrusted-deploys-policy
- With **Build without sensitive variables**, untrusted deploys build automatically but sensitive vars are **not passed**, so extensions/integrations relying on them may **break in those Deploy Previews**. Fix by making the code build without them, or by setting a safe-to-expose value for the `deploy-preview` context.
- Vars marked `Contains secret values` are **always** sensitive. Others are detected heuristically by name (`PASSWORD`, `TOKEN`, `SECRET`, `API_KEY`, ...) and by value (known credential formats such as AWS access keys).
- **Heuristics aren't guaranteed.** Explicitly mark secrets so they're always excluded.

## Ignore builds

`ignore` under `[build]` decides whether to rebuild. It runs from the base directory in Bash, or in Node.js 18 (fixed version; site `package.json` deps are **not** available).
- **Exit `1` = changed → build continues.**
- **Exit `0` = no change → build stops.**
- A build hook always builds, regardless of exit code.
```toml
[build]
  ignore = "git diff --quiet $CACHED_COMMIT_REF $COMMIT_REF packages/blog-1 packages/common"
```
```toml
[build]
  ignore = "node ignore_build.js"   # separate file paths must start with ./
```
```js
// ignore_build.js
process.exitCode = process.env.BRANCH.includes("debug") ? 0 : 1
```

## Monorepos

Recommended setup:
1. Set the site subdirectory as the **package directory** and keep its `netlify.toml` there.
2. Leave the base directory at root `/`.
3. Declare deps at the subdirectory level.

The package directory is **UI-only and cannot be set in `netlify.toml`**. Set it at Project configuration > Developer settings > Continuous deployment > Build settings.

Config files are discovered in this order: package dir → base dir → root. Paths in `netlify.toml` stay absolute relative to the base directory. Use `netlify <cmd> --filter <site>` to select a site.

## JavaScript SPAs

- Build command: `npm run <script>` or `yarn <script>`.
- Publish dir: often `dist`, depending on the framework.
- Add the `/*  /index.html  200` fallback (above) for `pushState` routing.
- Code splitting + hashed filenames with atomic deploys can throw `Uncaught SyntaxError: Unexpected token` on stale references. Fix by disabling hashed filenames, using permalinks, or using a service worker.

## Netlify Dev `[dev]`

`[dev]` does **NOT** run in Bash, so don't use Bash syntax in `command`. There is **no `environment` key**; set local env vars under `[context.dev.environment]`.
```toml
[dev]
  command = "yarn start"
  targetPort = 3000        # if both command + targetPort set, framework must be "#custom"
  port = 8888
  framework = "#custom"
  [dev.https]
    certFile = "cert.pem"
    keyFile = "key.pem"
```

## Plugins & extensions

```toml
[[plugins]]
package = "netlify-plugin-check-output-for-puppy-references"
  [plugins.inputs]
  breeds = ["pomeranian", "chihuahua"]

[[integrations]]              # build-time extension; install on team first
  name = "abc-performance-extension"
  [integrations.config]
    output_path = "reports/performance-reports.html"
```

## Reference pages
- Build environment variables: https://docs.netlify.com/build/configure-builds/environment-variables.md
- Env-var overview: https://docs.netlify.com/build/environment-variables/overview.md
- Secrets Controller: https://docs.netlify.com/build/environment-variables/secrets-controller.md
- Redirects: https://docs.netlify.com/manage/routing/redirects/overview.md
- Redirect options: https://docs.netlify.com/manage/routing/redirects/redirect-options.md
- Rewrites/proxies: https://docs.netlify.com/manage/routing/redirects/rewrites-proxies.md
- Custom headers: https://docs.netlify.com/manage/routing/headers.md
- File-based config: https://docs.netlify.com/build/configure-builds/file-based-configuration.md
- Netlify Server configuration: https://docs.netlify.com/build/server/configuration/

<!-- Untrusted deploys policy options, default, config location, and plan gating are documented outside this grouping's sources.
Full [server] keys, valid regions/sizes, defaults, and plan gating for Netlify Server are not documented in this grouping's sources. -->

<!-- system: agent-context/config/system.md — human-owned, merged by ctx-gen; edit system.md, not this section -->
# Netlify house rules (config)

These are org conventions, not docs facts — merged into the rendered skill by
ctx-gen and never generated. Owned by the skills maintainer.

1. Env vars set in `netlify.toml` are NOT available to functions or edge
   functions at runtime — reading them there returns `undefined`. Set
   runtime vars in the UI or with `netlify env:set`, not `netlify.toml`.
2. Never put secrets in client-prefixed env vars (`VITE_`, `NEXT_PUBLIC_`,
   `PUBLIC_`, ...) — they are inlined into the client bundle; `--secret`
   does not protect them.
3. When snapshotting env vars locally (`netlify env:list --plain > .env`),
   keep `.env` gitignored — never commit it.
4. State env-var scope interaction explicitly: a site variable scoped to
   Builds does not shadow the shared variable for other scopes — precedence
   resolves independently per scope (site beats shared only within the
   scopes the site variable actually carries).
5. When creating or editing `netlify.toml`, add
   `"$schema" = "https://open-api.netlify.com/netlify.schema.json"` as its
   first line if it's missing, and check property names and value types
   against that schema instead of guessing. The schema doesn't describe the
   contents of `[dev]`, `[template]`, `[[integrations]]` or
   `[build.processing]`; use the docs for those.
